[1.0.0] - 2025-06-04

--Added

-Sistema de autenticación y gestión de usuarios.

-Registro automático en tablas de Estudiantes o Profesores según el rol asignado.

-Gestión de grados, materias, estudiantes, profesores.

-Asociación entre asignaturas, profesores y estudiantes.

-Formularios desacoplados para mayor modularidad en las vistas.

-Vistas base unificadas con diseño visual coherente entre secciones.

-Vista de edición de perfil con formulario personalizado.